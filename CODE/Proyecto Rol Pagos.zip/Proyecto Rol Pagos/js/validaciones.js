function Acceso(){
	var usuario = document.getElementById("usuario").value;
	var clave = document.getElementById("clave").value;
	if(usuario == "administrador1" && clave == "nominas.2022"){	
		window.open("html/inicio.html");
	}else{
		alert("Usuario o contraseña incorrecta");
		document.getElementById("usuario").value = "";
		document.getElementById("clave").value = "";
	}
}