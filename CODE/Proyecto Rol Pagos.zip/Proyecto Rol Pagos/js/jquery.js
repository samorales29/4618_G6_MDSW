$(document).ready(function(){

    $('#agregar').click(function(){
        let nombre = $('#nombre').val();
        let subdepartamento = $('#subdepartamento').val();
        let centroCostos = $('#centroCostos').val();
        let cargo = $('#cargo').val();
        let cedula = $('#cedula').val();
        let fecha = $('#fecha').val();

        $('#datos').append("<tr><td>" + nombre + "</td><td>" + subdepartamento + "</td><td>" + centroCostos + "</td><td>" +  cargo + "</td><td>" 
        + cedula + "</td><td>" + fecha + "</td><td>" + '<a href="#"><i class="fas fa-edit"></i></a> | <a href="#"><i class="fas fa-user-times"></i></a>' + "</td></tr>");
    });
    
});