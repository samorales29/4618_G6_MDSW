var Fila = null
function agregarUsuarios() {
    let DataForm = Leer()
    if (Fila == null) {
        InsertarDatos(DataForm)
    } else {
        Actualizar(DataForm)
        Vaciar()
    }
}
function Leer() {
    let DataForm = {}
    DataForm["ced"] = document.getElementById("ced").value
    DataForm["nom"] = document.getElementById("nom").value
    DataForm["centro"] = document.getElementById("centro").value
    DataForm["cargo"] = document.getElementById("cargo").value
    DataForm["fecha"] = document.getElementById("fecha").value
    return DataForm
}
function InsertarDatos(data) {
    let table = document.getElementById("tabla").getElementsByTagName('tbody')[0]
    let Fila = table.insertRow(table.length)
    columna1 = Fila.insertCell(0).innerHTML = data.ced
    columna2 = Fila.insertCell(1).innerHTML = data.nom
    columna3 = Fila.insertCell(2).innerHTML = data.centro
    columna4 = Fila.insertCell(3).innerHTML = data.cargo
    columna5 = Fila.insertCell(4).innerHTML = data.fecha
    columna6 = Fila.insertCell(5).innerHTML = '<a href="#addModal" onClick="Editarr(this)" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Editar">&#xE254;</i></a>'
        + '<a href="#deleteModal" onClick="Borrarr(this)" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Borrar">&#xE872;</i></a>'
        + '</td></tbody>'
    document.getElementById("ced").focus()
    Vaciar()
}
function Vaciar() {
    document.getElementById("ced").value = ""
    document.getElementById("nom").value = ""
    document.getElementById("centro").value = ""
    document.getElementById("cargo").value = ""
    document.getElementById("fecha").value = ""
    Fila = null
}
function Editarr(td) {
    Fila = td.parentElement.parentElement
    document.getElementById("ced").value = Fila.cells[0].innerHTML
    document.getElementById("nom").value = Fila.cells[1].innerHTML
    document.getElementById("centro").value = Fila.cells[2].innerHTML
    document.getElementById("cargo").value = Fila.cells[3].innerHTML
    document.getElementById("fecha").value = Fila.cells[4].innerHTML
}
function Actualizar(DataForm) {
    Fila.cells[0].innerHTML = DataForm.ced
    Fila.cells[1].innerHTML = DataForm.nom
    Fila.cells[2].innerHTML = DataForm.centro
    Fila.cells[3].innerHTML = DataForm.cargo
    Fila.cells[4].innerHTML = DataForm.fecha
    document.getElementById("ced").focus()
}
function Borrarr(td) {
    if (confirm('¿Seguro de borrar este registro?')) {
        row = td.parentElement.parentElement
        document.getElementById("tabla").deleteRow(row.rowIndex)
        Vaciar()
    }
}