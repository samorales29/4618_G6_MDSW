// JavaScript Document
const tiempoTranscurrido = Date.now();
const hoy = new Date(tiempoTranscurrido);

function Acceso() {
	var usuario = document.getElementById("usuario").value;
	var clave = document.getElementById("clave").value;
	if (usuario == "administrador1" && clave == "nominas.2022") {
		window.open('html/crud.html', '_self');
	} else {
		alert("Usuario o contraseña incorrecta");
		document.getElementById("usuario").value = "";
		document.getElementById("clave").value = "";
	}
}

function validarCedula() {
	var cedula = null;

	cedula = document.getElementById("ced").value;

	//Preguntamos si la cedula consta de 10 digitos
	if (cedula.length == 10) {

		//Obtenemos el digito de la region que sonlos dos primeros digitos
		var digito_region = cedula.substring(0, 2);

		//Pregunto si la region existe ecuador se divide en 24 regiones
		if (digito_region >= 1 && digito_region <= 24) {

			// Extraigo el ultimo digito
			var ultimo_digito = cedula.substring(9, 10);

			var pares = parseInt(cedula.substring(1, 2)) + parseInt(cedula.substring(3, 4)) + parseInt(cedula.substring(5, 6)) + parseInt(cedula.substring(7, 8));

			var numero1 = cedula.substring(0, 1);
			var numero1 = (numero1 * 2);
			if (numero1 > 9) { var numero1 = (numero1 - 9); }

			var numero3 = cedula.substring(2, 3);
			var numero3 = (numero3 * 2);
			if (numero3 > 9) { var numero3 = (numero3 - 9); }

			var numero5 = cedula.substring(4, 5);
			var numero5 = (numero5 * 2);
			if (numero5 > 9) { var numero5 = (numero5 - 9); }

			var numero7 = cedula.substring(6, 7);
			var numero7 = (numero7 * 2);
			if (numero7 > 9) { var numero7 = (numero7 - 9); }

			var numero9 = cedula.substring(8, 9);
			var numero9 = (numero9 * 2);
			if (numero9 > 9) { var numero9 = (numero9 - 9); }

			var impares = numero1 + numero3 + numero5 + numero7 + numero9;

			var suma_total = (pares + impares);

			var primer_digito_suma = String(suma_total).substring(0, 1);

			var decena = (parseInt(primer_digito_suma) + 1) * 10;

			var digito_validador = decena - suma_total;

			if (digito_validador == 10)
				var digito_validador = 0;

			if (digito_validador == ultimo_digito) {
				document.getElementById('resultado1').innerHTML = '<p class="correcto"><strong>✓ Correcto: </strong>Cedula valida.</p>';
			} else {
				document.getElementById('resultado1').innerHTML = '<p class="error"><strong>Error: </strong>¡Esta cédula no pertenece a ninguna región!</p>';
				document.getElementById("ced").value = "";
			}

		} else {
			document.getElementById('resultado1').innerHTML = '<p class="error"><strong>Error: </strong>¡Solo se permiten caracteres numéricos!</p>';
			document.getElementById("ced").value = "";
		}
	} else {
		document.getElementById('resultado1').innerHTML = '<p class="error"><strong>Error: </strong>¡La cédula tiene menos de 10 caracteres!</p>';
		document.getElementById("ced").value = "";
	}
}

function validarNombre() {
	var regName = /^\b([A-ZÀ-ÿ][-,a-z]+[ ]*)+$/;
	var nombre = document.getElementById('nom').value;

	if (nombre != '') {

		if (!regName.test(nombre)) {
			document.getElementById('resultado2').innerHTML = '<p class="error"><strong>Error: </strong>¡Ingrese un nombre y apellido correctamente!</p>';
			document.getElementById('nom').focus();
			document.getElementById("nom").value = "";
		} else {
			document.getElementById('resultado2').innerHTML = '<p class="correcto"><strong>✓ Correcto: </strong>Nombre y Apellido validos.</p>';
		}
	} else {
		//si los campos o uno, este vacio
		document.getElementById('resultado2').innerHTML = '<p class="error"><strong>Error: </strong>¡Los campos no deben estar vacios!</p>';
		document.getElementById("nom").value = "";
	}
}

function validarCentro() {
	var regCentro = /^\b([A-ZÀ-ÿ][-,a-z]+[ ]*)+$/;
	var centro = document.getElementById('centro').value;

	if (centro != '') {

		if (!regCentro.test(centro)) {
			document.getElementById('resultado3').innerHTML = '<p class="error"><strong>Error: </strong>¡Ingrese un centro de costos correctamente!</p>';
			document.getElementById('centro').focus();
			document.getElementById("centro").value = "";
		} else {
			document.getElementById('resultado3').innerHTML = '<p class="correcto"><strong>✓ Correcto: </strong>Centro de Costos valido.</p>';
		}
	} else {
		//si los campos o uno, este vacio
		document.getElementById('resultado3').innerHTML = '<p class="error"><strong>Error: </strong>¡Los campos no deben estar vacios!</p>';
		document.getElementById("centro").value = "";
	}
}

function validarCargo() {
	var regCargo = /^\b([A-ZÀ-ÿ][-,a-z]+[ ]*)+$/;
	var cargo = document.getElementById('cargo').value;

	if (cargo != '') {

		if (!regCargo.test(cargo)) {
			document.getElementById('resultado4').innerHTML = '<p class="error"><strong>Error: </strong>¡Ingrese un cargo correctamente!</p>';
			document.getElementById('cargo').focus();
			document.getElementById("cargo").value = "";
		} else {
			document.getElementById('resultado4').innerHTML = '<p class="correcto"><strong>✓ Correcto: </strong>Cargo valido.</p>';
		}
	} else {
		//si los campos o uno, este vacio
		document.getElementById('resultado4').innerHTML = '<p class="error"><strong>Error: </strong>¡Los campos no deben estar vacios!</p>';
		document.getElementById("cargo").value = "";
	}
}
function insertarFecha(){
	document.getElementById('fecha').focus();
	document.getElementById("fecha").value = hoy.toLocaleDateString();
}
