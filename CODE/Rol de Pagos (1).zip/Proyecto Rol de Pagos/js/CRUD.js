// JavaScript Document
var data_json = [];
var Fila = null;

function leerTXT() {
  //Imprimir arreglo
  data_json.forEach((object) => {
    document.getElementById("tabla").innerHTML +=
      "<tbody><td>" +
      object.cedula +
      "</td><td>" +
      object.nombre +
      "</td><td>" +
      object.centro +
      "</td><td>" +
      object.cargo +
      "</td><td>" +
      object.fecha +
      "</td><td>" +
      object.total + 
      '<a href="#editModal" onClick="Editarr(this)" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Editar">&#xE254;</i></a>' +
      '<a href="#deleteModal" onClick="Borrarr(this)" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Borrar">&#xE872;</i></a>' +
      '<a href="#payModal" onClick="InformacionPersonal(this)" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Generar Rol">&#xE227;</i></a>' +
      '<a href="#" onClick="generarUsuariosTxt()" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Descargar Usuario">&#xE2C4;</i></a>' +
      "</td></tbody>";
  });
}
leerTXT();

function agregarcargos() {
  class cargo {
    constructor(cedula, nombre, centro, cargo, fecha, total) {
      this.cedula = cedula;
      this.nombre = nombre;
      this.centro = centro;
      this.cargo = cargo;
      this.fecha = fecha;
      this.total = total;
    }
  }
  var combo1 = document.getElementById("centro1");
  var combo2 = document.getElementById("cargo1");

  var cedulaCapturar = document.getElementById("ced1").value;
  var nombreCapturar = document.getElementById("nom1").value;
  var centroCapturar = combo1.options[combo1.selectedIndex].text;
  var cargoCapturar = combo2.options[combo2.selectedIndex].text;
  var fechaCapturar = document.getElementById("fecha1").value;
  var totalCapturar = document.getElementById("sueldoA").value;

  var nuevoReporte = new cargo(
    cedulaCapturar,
    nombreCapturar,
    centroCapturar,
    cargoCapturar,
    fechaCapturar,
    totalCapturar
  );

  console.log(nuevoReporte);
  agregar(nuevoReporte);
  Vaciar();
}

function agregar(nuevoReporte) {
  data_json.push(nuevoReporte);
  console.log(data_json);

  document.getElementById("tabla").innerHTML +=
    "<tbody><td>" +
    nuevoReporte.cedula +
    "</td><td>" +
    nuevoReporte.nombre +
    "</td><td>" +
    nuevoReporte.centro +
    "</td><td>" +
    nuevoReporte.cargo +
    "</td><td>" +
    nuevoReporte.fecha +
    "</td><td>" +
    nuevoReporte.total +
    "</td><td>" +
    '<a href="#editModal" onClick="Editarr(this)" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Editar">&#xE254;</i></a>' +
    '<a href="#deleteModal" onClick="Borrarr(this)" class="delete" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Borrar">&#xE872;</i></a>' +
    '<a href="#payModal" onClick="InformacionPersonal(this)" class="edit" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Generar Rol">&#xE227;</i></a>' +
    '<a href="#" onClick="generarTxt(this)" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Descargar Usuario">&#xE2C4;</i></a>' +
    "</td></tbody>";
}

function Vaciar() {
  document.getElementById("ced1").value = "";
  document.getElementById("nom1").value = "";
  document.getElementById("centro1").value = "";
  document.getElementById("cargo1").value = "";
  document.getElementById("fecha1").value = "";
  document.getElementById("sueldoA").value = "";
  Fila = null;
}

function calcularTotal() {

  //Ingresos
  var sueldo = parseFloat(document.getElementById("sueldo").value);
  var refrigerio = parseFloat(document.getElementById("refrigerio").value);
  var extras = parseFloat(document.getElementById("extras").value);
  var fondos = parseFloat(document.getElementById("fondos").value);
  //Egresos
  var iess = parseFloat(document.getElementById("iess").value);
  var asistencia = parseFloat(document.getElementById("asistencia").value);
  var descuentos = parseFloat(document.getElementById("descuentos").value);
  var asociacion = parseFloat(document.getElementById("asociacion").value);
  //Totales
  var totalIngresos = (sueldo + refrigerio + extras + fondos);
  var totalEgresos = (iess + asistencia + descuentos + asociacion);
  var netoPagar = (totalIngresos - totalEgresos);

  document.getElementById('totalIngresos').innerHTML= totalIngresos;
  document.getElementById('totalEgresos').innerHTML= totalEgresos;
  document.getElementById('neto').innerHTML = netoPagar;
  
  var capturarNeto = document.getElementById('neto').textContent;

  Fila.cells[5].innerHTML = capturarNeto;

  data_json.forEach((object) => {
    if (object.cedula == Fila.cells[0].innerHTML) {
      object.total = Fila.cells[5].innerHTML;
    }
  });
  document.getElementById("neto").focus();
  console.log(data_json);
}

function Editarr(td) {
  Fila = td.parentElement.parentElement;
  var combo1 = document.getElementById("centro2");
  var combo2 = document.getElementById("cargo2");

  document.getElementById("ced2").value = Fila.cells[0].innerHTML;
  document.getElementById("nom2").value = Fila.cells[1].innerHTML;
  combo1.options[combo1.selectedIndex].text = Fila.cells[2].innerHTML;
  combo2.options[combo2.selectedIndex].text = Fila.cells[3].innerHTML;
  document.getElementById("fecha2").value = Fila.cells[4].innerHTML;
  document.getElementById("total2").value = Fila.cells[5].innerHTML;
  document.getElementById("sueldoB").value = Fila.cells[5].innerHTML;
}

function Actualizar() {
  var combo1 = document.getElementById("centro2");
  var combo2 = document.getElementById("cargo2");

  Fila.cells[0].innerHTML = document.getElementById("ced2").value;
  Fila.cells[1].innerHTML = document.getElementById("nom2").value;
  Fila.cells[2].innerHTML = combo1.options[combo1.selectedIndex].text;
  Fila.cells[3].innerHTML = combo2.options[combo2.selectedIndex].text;
  Fila.cells[4].innerHTML = document.getElementById("fecha2").value;
  Fila.cells[5].innerHTML = document.getElementById("sueldoB").value;

  data_json.forEach((object) => {
    if (object.cedula == Fila.cells[0].innerHTML) {
      object.cedula = Fila.cells[0].innerHTML;
      object.nombre = Fila.cells[1].innerHTML;
      object.centro = Fila.cells[2].innerHTML;
      object.cargo = Fila.cells[3].innerHTML;
      object.fecha = Fila.cells[4].innerHTML;
      object.total = Fila.cells[5].innerHTML;
    }
  });
  document.getElementById("ced2").focus();
  console.log(data_json);
}

function InformacionPersonal(td) {
  Fila = td.parentElement.parentElement;
  var combo1 = document.getElementById("centro3");
  var combo2 = document.getElementById("cargo3");

  document.getElementById("ced3").value = Fila.cells[0].innerHTML;
  document.getElementById("nom3").value = Fila.cells[1].innerHTML;
  combo1.options[combo1.selectedIndex].text = Fila.cells[2].innerHTML;
  combo2.options[combo2.selectedIndex].text = Fila.cells[3].innerHTML;
  document.getElementById("fecha3").value = Fila.cells[4].innerHTML;
}

function Borrarr(td) {
  if (confirm("¿Seguro de borrar este registro?")) {
    row = td.parentElement.parentElement;
    document.getElementById("tabla").deleteRow(row.rowIndex);
    Vaciar();
  }
}

function descargar(nombre, texto) {
  const element = document.createElement("a");
  element.setAttribute("href","data:text/plain;charset=utf-8," + encodeURIComponent(texto)
  );
  element.setAttribute("download", nombre);

  element.style.display = "none";
  document.body.appendChild(element);
  element.click();

  document.body.removeChild(element);
}
function generarTxt(td) {
  var texto = "";
  
  Fila = td.parentElement.parentElement;
  var combo1 = document.getElementById("centro2");
  var combo2 = document.getElementById("cargo2");

  document.getElementById("ced2").value = Fila.cells[0].innerHTML;
  document.getElementById("nom2").value = Fila.cells[1].innerHTML;
  combo1.options[combo1.selectedIndex].text = Fila.cells[2].innerHTML;
  combo2.options[combo2.selectedIndex].text = Fila.cells[3].innerHTML;
  document.getElementById("fecha2").value = Fila.cells[4].innerHTML;
  document.getElementById("neto").value = Fila.cells[5].innerHTML;

  texto += 
  '"Cedula":'+ Fila.cells[0].innerHTML +
      "," +
      '"Nombre":'+ Fila.cells[1].innerHTML +
      "," +
      '"Centro de Costos":' + Fila.cells[2].innerHTML +
      "," +
      '"Cargo":' + Fila.cells[3].innerHTML +
      "," +
      '"Fecha":' + Fila.cells[4].innerHTML +
      "," +
      '"Sueldo":' + Fila.cells[5].innerHTML +
      "\n";
    console.log(texto);
  if (descargar("Usuario.txt", texto)) {
    alert("Datos Descargados Exitosamente.");
  }
}

function generarUsuariosTxt() {
  var texto = "";
  data_json.forEach((object) => {
    texto +=
      '"Cedula":'+ object.cedula +
      "," +
      '"Nombre":'+ object.nombre +
      "," +
      '"Centro de Costos":' + object.centro +
      "," +
      '"Cargo":' + object.cargo +
      "," +
      '"Fecha":' + object.fecha +
      "," +
      '"Sueldo":' + object.total +
      "\n";
    console.log(texto);
  });
  if (descargar("Roles de Pago.txt", texto)) {
    alert("Datos Descargados Exitosamente.");
  }
}

function doSearch() {
  const tableReg = document.getElementById("tabla");
  const searchText = document.getElementById("search").value.toLowerCase();
  let total = 0;
  // Recorremos todas las filas con contenido de la tabla
  for (let i = 1; i < tableReg.rows.length; i++) {
    let found = false;
    const cellsOfRow = tableReg.rows[i].getElementsByTagName("td");
    // Recorremos todas las celdas
    for (let j = 0; j < cellsOfRow.length && !found; j++) {
      const compareWith = cellsOfRow[j].innerHTML.toLowerCase();
      // Buscamos el texto en el contenido de la celda
      if (searchText.length == 0 || compareWith.indexOf(searchText) > -1) {
        found = true;
        total++;
      }
    }
    if (found) {
      tableReg.rows[i].style.display = "";
    } else {
      // Si no ha encontrado ninguna coincidencia, esconde la fila de la tabla
      tableReg.rows[i].style.display = "none";
    }
  }
}
function validarRepetidos() {
  var cedular = document.getElementById("ced1").value;
  data_json.forEach((object) => {
    if (object.cedula == cedular) {
      document.getElementById("resultado1").innerHTML =
        '<p class="error"><strong>Error: </strong>Esta cedula ya se encuentra registrada !</p>';
      document.getElementById("ced1").value = "";
    }
  });
}
function validarRepetidos2() {
  var cedular = document.getElementById("ced2").value;
  data_json.forEach((object) => {
    if (object.cedula == cedular) {
      document.getElementById("resultado6").innerHTML =
        '<p class="error"><strong>Error: </strong>Esta cedula ya se encuentra registrada !</p>';
      document.getElementById("ced2").value = "";
    }
  });
}

/* 10x2 y 11x2 
  


*/